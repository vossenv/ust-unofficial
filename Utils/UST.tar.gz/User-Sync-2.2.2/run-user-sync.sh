#!/usr/bin/env bash
./user-sync --users mapped --process-groups