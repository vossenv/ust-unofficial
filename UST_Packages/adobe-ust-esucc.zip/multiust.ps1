$configList = @()
Get-ChildItem -Path "districts" | ForEach-Object { if ($_.PSIsContainer) {
        Get-ChildItem -Path $_.FullName | ForEach-Object {
            if ($_.Name -match "user-sync-config") {
                $configList+=($_.FullName)
            }
        }
    }
}

# Run the tool
foreach ($c in $configList){
    python .\user-sync-multi.pex -c $c $args
}

